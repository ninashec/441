//
//  swiftUIChatterTests.swift
//  swiftUIChatterTests
//
//  Created by Nina Sheckler on 1/25/25.
//

import Testing
@testable import swiftUIChatter

struct swiftUIChatterTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
